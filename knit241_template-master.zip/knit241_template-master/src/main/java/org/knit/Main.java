package org.knit;

import org.knit.lab1.Task1;
import org.knit.lab1.Task2;

public class Main {
    public static void main(String[] args) {
        Task1 task1 = new Task1();
        task1.execute();

        Task2 task2 = new Task2();
        task2.execute();
    }
}
